# Maps → Uber APK

الهدف: بناء APK من الهاتف فقط باستخدام GitHub Actions.

## المطلوب منك
1. أنشئ حساب GitHub إن لم يكن لديك.
2. أنشئ Repository جديد باسم MapsToUber واجعله Public أو Private.
3. ارفع محتويات مجلد MapsToUberAPK إلى الـRepository، وليس ملف ZIP نفسه.
4. افتح تبويب Actions في الـRepository.
5. اختر Build APK من القائمة ثم Run workflow.
6. انتظر انتهاء المهمة.
7. افتح نتيجة التشغيل الناجح، وانزل إلى Artifacts.
8. نزّل MapsToUber-debug-apk.zip، فك الضغط، وثبّت app-debug.apk.

الـWorkflow مضاف بالفعل داخل .github/workflows/build-apk.yml، فلا تحتاج كتابة أي كود على GitHub.
